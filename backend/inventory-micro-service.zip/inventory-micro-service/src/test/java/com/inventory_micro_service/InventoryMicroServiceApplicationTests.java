package com.inventory_micro_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
